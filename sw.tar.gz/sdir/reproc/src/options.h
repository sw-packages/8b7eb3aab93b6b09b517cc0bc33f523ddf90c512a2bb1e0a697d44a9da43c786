#pragma once

#include <reproc/reproc.h>

int parse_options(reproc_options *options, const char *const *argv);
